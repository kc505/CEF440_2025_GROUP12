import 'package:flutter/material.dart';

enum UserRole { student, lecturer, admin }

class AuthProvider with ChangeNotifier {
  bool _isAuthenticated = false;
  UserRole? _userRole;
  Map<String, dynamic>? _userData;
  String? _token;

  bool get isAuthenticated => _isAuthenticated;
  UserRole? get userRole => _userRole;
  Map<String, dynamic>? get userData => _userData;
  String? get token => _token;

  // Student login with matricule number, email, and password
  Future<bool> loginStudent(String matricule, String email, String password) async {
    try {
      // TODO: Implement actual API call to backend for student login
      // Example API call:
      // final response = await http.post(
      //   Uri.parse('${ApiConstants.baseUrl}/auth/student/login'),
      //   headers: {'Content-Type': 'application/json'},
      //   body: jsonEncode({
      //     'matricule': matricule,
      //     'email': email,
      //     'password': password,
      //   }),
      // );
      
      // Simulate API call delay
      await Future.delayed(const Duration(seconds: 2));
      
      // Mock successful login
      _isAuthenticated = true;
      _userRole = UserRole.student;
      _token = 'student_token_${DateTime.now().millisecondsSinceEpoch}';
      _userData = {
        'matricule': matricule,
        'email': email,
        'name': 'TIWA DELAN', // This would come from API response
        'role': 'student',
      };
      
      notifyListeners();
      return true;
    } catch (e) {
      print('Student login error: $e');
      return false;
    }
  }

  // Lecturer login with faculty number, email, and password
  Future<bool> loginLecturer(String facultyNumber, String email, String password) async {
    try {
      // TODO: Implement actual API call to backend for lecturer login
      // Example API call:
      // final response = await http.post(
      //   Uri.parse('${ApiConstants.baseUrl}/auth/lecturer/login'),
      //   headers: {'Content-Type': 'application/json'},
      //   body: jsonEncode({
      //     'facultyNumber': facultyNumber,
      //     'email': email,
      //     'password': password,
      //   }),
      // );
      
      // Simulate API call delay
      await Future.delayed(const Duration(seconds: 2));
      
      // Mock successful login
      _isAuthenticated = true;
      _userRole = UserRole.lecturer;
      _token = 'lecturer_token_${DateTime.now().millisecondsSinceEpoch}';
      _userData = {
        'facultyNumber': facultyNumber,
        'email': email,
        'name': 'Dr. Jane Smith', // This would come from API response
        'role': 'lecturer',
      };
      
      notifyListeners();
      return true;
    } catch (e) {
      print('Lecturer login error: $e');
      return false;
    }
  }

  // Admin login with email and password only
  Future<bool> loginAdmin(String email, String password) async {
    try {
      // TODO: Implement actual API call to backend for admin login
      // Example API call:
      // final response = await http.post(
      //   Uri.parse('${ApiConstants.baseUrl}/auth/admin/login'),
      //   headers: {'Content-Type': 'application/json'},
      //   body: jsonEncode({
      //     'email': email,
      //     'password': password,
      //   }),
      // );
      
      // Simulate API call delay
      await Future.delayed(const Duration(seconds: 2));
      
      // Mock successful login
      _isAuthenticated = true;
      _userRole = UserRole.admin;
      _token = 'admin_token_${DateTime.now().millisecondsSinceEpoch}';
      _userData = {
        'email': email,
        'name': 'System Administrator', // This would come from API response
        'role': 'admin',
      };
      
      notifyListeners();
      return true;
    } catch (e) {
      print('Admin login error: $e');
      return false;
    }
  }

  // Signup method (existing)
  Future<bool> signup(String name, String email, String password, String role) async {
    try {
      // TODO: Implement actual API call to backend with role parameter
      // Simulating successful signup
      _isAuthenticated = true;
      _token = 'sample_token';
      _userData = {
        'name': name,
        'email': email,
        'role': role,
      };
      
      // Set user role based on signup role
      switch (role) {
        case 'student':
          _userRole = UserRole.student;
          break;
        case 'lecturer':
          _userRole = UserRole.lecturer;
          break;
        case 'admin':
          _userRole = UserRole.admin;
          break;
      }
      
      notifyListeners();
      return true;
    } catch (e) {
      print('Signup error: $e');
      return false;
    }
  }

  void logout() {
    // TODO: Implement API call to invalidate token on backend
    // Example API call:
    // await http.post(
    //   Uri.parse('${ApiConstants.baseUrl}/auth/logout'),
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'Authorization': 'Bearer $_token',
    //   },
    // );
    
    _isAuthenticated = false;
    _token = null;
    _userData = null;
    _userRole = null;
    
    notifyListeners();
  }
}
