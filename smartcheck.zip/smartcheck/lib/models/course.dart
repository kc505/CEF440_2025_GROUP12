class Course {
  final String id;
  final String code;
  final String name;
  final String status;
  final String title;
  final String description;
  final int credits;
  final String? lecturer;
  final String? semester;
  final int? year;
  final int? totalStudents;

  Course({
    required this.id,
    required this.code,
    required this.name,
    required this.status,
    required this.title,
    required this.description,
    required this.credits,
    this.lecturer,
    this.semester,
    this.year,
    this.totalStudents,
  });
}
