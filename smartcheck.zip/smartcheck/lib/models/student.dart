class Student {
  final String id;
  final String matriculeNumber;
  final String firstName;
  final String lastName;
  final String email;
  final String? phoneNumber;
  final String? profileImage;
  final List<String> enrolledCourses;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final bool isActive;

  Student({
    required this.id,
    required this.matriculeNumber,
    required this.firstName,
    required this.lastName,
    required this.email,
    this.phoneNumber,
    this.profileImage,
    required this.enrolledCourses,
    required this.createdAt,
    this.updatedAt,
    this.isActive = true,
  });

  String get fullName => '$firstName $lastName';

  factory Student.fromJson(Map<String, dynamic> json) {
    return Student(
      id: json['id'] ?? '',
      matriculeNumber: json['matricule_number'] ?? '',
      firstName: json['first_name'] ?? '',
      lastName: json['last_name'] ?? '',
      email: json['email'] ?? '',
      phoneNumber: json['phone_number'],
      profileImage: json['profile_image'],
      enrolledCourses: (json['enrolled_courses'] as List<dynamic>?)?.cast<String>() ?? [],
      createdAt: json['created_at'] != null ? DateTime.parse(json['created_at']) : DateTime.now(),
      updatedAt: json['updated_at'] != null ? DateTime.parse(json['updated_at']) : null,
      isActive: json['is_active'] ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'matricule_number': matriculeNumber,
      'first_name': firstName,
      'last_name': lastName,
      'email': email,
      'phone_number': phoneNumber,
      'profile_image': profileImage,
      'enrolled_courses': enrolledCourses,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
      'is_active': isActive,
    };
  }
}
