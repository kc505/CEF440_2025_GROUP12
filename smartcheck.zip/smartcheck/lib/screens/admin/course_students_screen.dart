import 'package:flutter/material.dart';
import '../../utils/app_theme.dart';
import '../../models/course.dart';
import '../../models/student.dart';

class CourseStudentsScreen extends StatefulWidget {
  final Course course;
  
  const CourseStudentsScreen({Key? key, required this.course}) : super(key: key);

  @override
  State<CourseStudentsScreen> createState() => _CourseStudentsScreenState();
}

class _CourseStudentsScreenState extends State<CourseStudentsScreen> {
  List<Student> _students = [];
  bool _isLoading = true;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadStudents();
  }

  Future<void> _loadStudents() async {
    setState(() => _isLoading = true);
    
    try {
      // TODO: Implement API call to fetch students for this course
      // final response = await http.get(
      //   Uri.parse('${ApiConstants.baseUrl}/admin/courses/${widget.course.id}/students'),
      //   headers: {'Authorization': 'Bearer ${authProvider.token}'},
      // );
      
      await Future.delayed(const Duration(seconds: 1));
      
      // Mock data
      _students = [
        Student(
          id: '1',
          matricule: 'CSC/2021/001',
          name: 'Alice Johnson',
          email: 'alice.johnson@university.edu',
          totalSessions: 8,
          attendedSessions: 7,
          attendanceRate: 87.5,
        ),
        Student(
          id: '2',
          matricule: 'CSC/2021/002',
          name: 'Bob Smith',
          email: 'bob.smith@university.edu',
          totalSessions: 8,
          attendedSessions: 6,
          attendanceRate: 75.0,
        ),
        Student(
          id: '3',
          matricule: 'CSC/2021/003',
          name: 'Carol Davis',
          email: 'carol.davis@university.edu',
          totalSessions: 8,
          attendedSessions: 8,
          attendanceRate: 100.0,
        ),
        Student(
          id: '4',
          matricule: 'CSC/2021/004',
          name: 'David Wilson',
          email: 'david.wilson@university.edu',
          totalSessions: 8,
          attendedSessions: 5,
          attendanceRate: 62.5,
        ),
        Student(
          id: '5',
          matricule: 'CSC/2021/005',
          name: 'Eva Brown',
          email: 'eva.brown@university.edu',
          totalSessions: 8,
          attendedSessions: 7,
          attendanceRate: 87.5,
        ),
      ];
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading students: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  List<Student> get _filteredStudents {
    if (_searchQuery.isEmpty) return _students;
    
    return _students.where((student) {
      return student.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
             student.matricule.toLowerCase().contains(_searchQuery.toLowerCase()) ||
             student.email.toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();
  }

  Color _getAttendanceColor(double rate) {
    if (rate >= 80) return Colors.green;
    if (rate >= 60) return Colors.orange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: Text('${widget.course.code} Students'),
        backgroundColor: AppTheme.primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadStudents,
          ),
        ],
      ),
      body: Column(
        children: [
          // Course Info Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: AppTheme.primaryColor.withOpacity(0.1),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.course.title,
                  style: AppTheme.headingStyle.copyWith(
                    color: AppTheme.primaryColor,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Total Students: ${_students.length} | Completed Sessions: ${widget.course.completedSessions}/${widget.course.totalSessions}',
                  style: AppTheme.bodyStyle.copyWith(
                    color: Colors.grey[700],
                  ),
                ),
              ],
            ),
          ),
          
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search students by name, matricule, or email...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                filled: true,
                fillColor: Colors.white,
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
            ),
          ),
          
          // Students List
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredStudents.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.search_off,
                              size: 64,
                              color: Colors.grey[400],
                            ),
                            const SizedBox(height: 16),
                            Text(
                              _searchQuery.isEmpty 
                                  ? 'No students enrolled'
                                  : 'No students match your search',
                              style: AppTheme.bodyStyle.copyWith(
                                color: Colors.grey[600],
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: _filteredStudents.length,
                        itemBuilder: (context, index) {
                          final student = _filteredStudents[index];
                          return _buildStudentCard(student);
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildStudentCard(Student student) {
    final attendanceColor = _getAttendanceColor(student.attendanceRate);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Student Header
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
                  child: Text(
                    student.name.split(' ').map((n) => n[0]).take(2).join(),
                    style: TextStyle(
                      color: AppTheme.primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        student.name,
                        style: AppTheme.bodyStyle.copyWith(
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        student.matricule,
                        style: AppTheme.bodyStyle.copyWith(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        student.email,
                        style: AppTheme.bodyStyle.copyWith(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                // Attendance Badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: attendanceColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: attendanceColor.withOpacity(0.3)),
                  ),
                  child: Text(
                    '${student.attendanceRate.toInt()}%',
                    style: TextStyle(
                      color: attendanceColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            
            // Attendance Details
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: _buildAttendanceDetail(
                      'Sessions Attended',
                      '${student.attendedSessions}',
                      Icons.check_circle,
                      Colors.green,
                    ),
                  ),
                  Container(
                    width: 1,
                    height: 30,
                    color: Colors.grey[300],
                  ),
                  Expanded(
                    child: _buildAttendanceDetail(
                      'Total Sessions',
                      '${student.totalSessions}',
                      Icons.calendar_today,
                      Colors.blue,
                    ),
                  ),
                  Container(
                    width: 1,
                    height: 30,
                    color: Colors.grey[300],
                  ),
                  Expanded(
                    child: _buildAttendanceDetail(
                      'Missed',
                      '${student.totalSessions - student.attendedSessions}',
                      Icons.cancel,
                      Colors.red,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            
            // Action Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () {
                    // TODO: Navigate to student attendance history
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Student History - Coming Soon')),
                    );
                  },
                  icon: const Icon(Icons.history, size: 16),
                  label: const Text('View History'),
                  style: TextButton.styleFrom(
                    foregroundColor: AppTheme.primaryColor,
                  ),
                ),
                const SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () {
                    // TODO: Navigate to edit student attendance
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Edit Student Attendance - Coming Soon')),
                    );
                  },
                  icon: const Icon(Icons.edit, size: 16),
                  label: const Text('Edit'),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.orange,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAttendanceDetail(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(height: 4),
        Text(
          value,
          style: AppTheme.bodyStyle.copyWith(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            color: color,
          ),
        ),
        Text(
          label,
          textAlign: TextAlign.center,
          style: AppTheme.bodyStyle.copyWith(
            fontSize: 10,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }
}
