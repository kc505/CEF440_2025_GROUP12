import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../utils/app_theme.dart';
import '../../widgets/custom_text_field.dart';
import '../../widgets/custom_button.dart';
import '../../models/geofence_venue.dart';

class AddGeofenceVenueScreen extends StatefulWidget {
  const AddGeofenceVenueScreen({Key? key}) : super(key: key);

  @override
  State<AddGeofenceVenueScreen> createState() => _AddGeofenceVenueScreenState();
}

class _AddGeofenceVenueScreenState extends State<AddGeofenceVenueScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _radiusController = TextEditingController(text: '50');
  
  GoogleMapController? _mapController;
  LatLng _selectedLocation = const LatLng(6.5244, 3.3792); // Default to Lagos
  Set<Marker> _markers = {};
  Set<Circle> _circles = {};
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _updateMapMarkers();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _radiusController.dispose();
    super.dispose();
  }

  void _updateMapMarkers() {
    final radius = double.tryParse(_radiusController.text) ?? 50.0;
    
    setState(() {
      _markers = {
        Marker(
          markerId: const MarkerId('selected_location'),
          position: _selectedLocation,
          draggable: true,
          onDragEnd: (LatLng position) {
            setState(() {
              _selectedLocation = position;
              _updateMapMarkers();
            });
          },
        ),
      };
      
      _circles = {
        Circle(
          circleId: const CircleId('geofence_radius'),
          center: _selectedLocation,
          radius: radius,
          fillColor: AppTheme.primaryColor.withOpacity(0.2),
          strokeColor: AppTheme.primaryColor,
          strokeWidth: 2,
        ),
      };
    });
  }

  void _onMapTap(LatLng position) {
    setState(() {
      _selectedLocation = position;
      _updateMapMarkers();
    });
  }

  Future<void> _saveVenue() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      // TODO: Implement API call to save geofence venue
      await Future.delayed(const Duration(seconds: 2));
      
      final venue = GeofenceVenue(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim(),
        latitude: _selectedLocation.latitude,
        longitude: _selectedLocation.longitude,
        radius: double.parse(_radiusController.text),
        isActive: true,
      );

      if (mounted) {
        Navigator.of(context).pop(venue);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Geofence venue created successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error creating venue: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: const Text('Add Geofence Venue'),
        backgroundColor: AppTheme.primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Map Section
            Container(
              height: 300,
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: GoogleMap(
                  onMapCreated: (GoogleMapController controller) {
                    _mapController = controller;
                  },
                  initialCameraPosition: CameraPosition(
                    target: _selectedLocation,
                    zoom: 16,
                  ),
                  markers: _markers,
                  circles: _circles,
                  onTap: _onMapTap,
                  myLocationEnabled: true,
                  myLocationButtonEnabled: true,
                  mapToolbarEnabled: false,
                ),
              ),
            ),
            
            // Form Section
            Padding(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Venue Details',
                      style: AppTheme.headingStyle.copyWith(
                        fontSize: 18,
                        color: AppTheme.primaryColor,
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    CustomTextField(
                      controller: _nameController,
                      label: 'Venue Name',
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'Please enter venue name';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    
                    CustomTextField(
                      controller: _descriptionController,
                      label: 'Description (Optional)',
                    ),
                    const SizedBox(height: 16),
                    
                    CustomTextField(
                      controller: _radiusController,
                      label: 'Geofence Radius (meters)',
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'Please enter radius';
                        }
                        final radius = double.tryParse(value!);
                        if (radius == null || radius <= 0) {
                          return 'Please enter a valid radius';
                        }
                        if (radius > 1000) {
                          return 'Radius cannot exceed 1000 meters';
                        }
                        return null;
                      },
                      onChanged: (value) {
                        // Update circle radius in real-time
                        Future.delayed(const Duration(milliseconds: 500), () {
                          _updateMapMarkers();
                        });
                      },
                    ),
                    const SizedBox(height: 16),
                    
                    // Location Info
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey[50],
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.grey[300]!),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Selected Location',
                            style: AppTheme.bodyStyle.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.gps_fixed, size: 16, color: Colors.grey[600]),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Lat: ${_selectedLocation.latitude.toStringAsFixed(6)}\nLng: ${_selectedLocation.longitude.toStringAsFixed(6)}',
                                  style: AppTheme.bodyStyle.copyWith(
                                    fontSize: 12,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    
                    // Instructions
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.info_outline,
                            color: AppTheme.primaryColor,
                            size: 20,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'Tap on the map or drag the marker to set the venue location. The blue circle shows the geofence area.',
                              style: AppTheme.bodyStyle.copyWith(
                                fontSize: 12,
                                color: AppTheme.primaryColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                    
                    CustomButton(
                      text: 'Create Venue',
                      onPressed: _isLoading ? null : () => _saveVenue(),
                      isLoading: _isLoading,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
